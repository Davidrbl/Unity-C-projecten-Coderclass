class Product
{
  public string name;
  public double price;
  public double btwPercentage;

  public Product(string nName, double nPrice, double nbtwPercentage)
  {
    name = nName;
    price = nPrice;
    btwPercentage = nbtwPercentage;
  }

  public double priceIncBtwCalc()
  {
    return price * btwPercentage;
  }

  public double priceExcBtwCalc()
  {
    return price;
  }
}