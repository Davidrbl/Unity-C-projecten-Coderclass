using System;
using System.Collections.Generic;
using System.Linq;

class MainClass{
  public static void Main(string[] args){
    double totalPrice = 0.00;
    double priceIncBTW = 0.00;
    int aantalBoodschappen = 3;
    Product[] allItems = {
      new Product("Appel", 1.5, 1.21),
      new Product("Banaan", 2.0, 1.21),
      new Product("Taart", 5.0, 1.21),
      new Product("Komkommer", 0.95, 1.21),
      new Product("Boter", 2.5, 1.21),
      new Product("Koffie", 3.0, 1.21),
      new Product("Kauwgom", 1.0, 1.21),
      new Product("Brood", 1.5, 1.21),
      new Product("Snoep", 2.0, 1.21),
      new Product("Kaas", 3.0, 1.21),
      new Product("Ham", 2.5, 1.21)
    };

    foreach (Product pro in allItems)
    {
      Console.WriteLine("{0} voor {1} euro?", pro.name, pro.price);
    }
    for (int i = 0; i < aantalBoodschappen; i++)
    {
      //Input halen van gebruiker
      Console.WriteLine("Wat wilt u kopen?");

      string boodschap = Console.ReadLine();
      //Kijken welk product dat is in de allItems list
      int boodschapIndex = -1;
      bool isCorrect = false;
      for (int j = 0; j < allItems.Count(); j++)
      {
        if (boodschap == allItems[j].name)
        {
          boodschapIndex = j;
          isCorrect = true;
        }
      }
      if (!isCorrect)
      {
        Console.WriteLine("oi die is er niet");
        aantalBoodschappen++;
      }
      //Console.WriteLine(boodschapIndex);
      Console.WriteLine("Hoeveel wil je daarvan?");
      int aantalBoodschap = 0;
      Int32.TryParse(Console.ReadLine(),out aantalBoodschap);
      //Prijs exc btw toevoegen aan totalPrice
      totalPrice += allItems[boodschapIndex].price * aantalBoodschap;
      priceIncBTW += allItems[boodschapIndex].price * aantalBoodschap * allItems[boodschapIndex].btwPercentage;
    }
    Console.WriteLine("Exclusief btw wordt dat {0} euro!" ,totalPrice);
    Console.WriteLine("Inclusief btw wordt dat {0} euro" ,priceIncBTW);
  }
}
