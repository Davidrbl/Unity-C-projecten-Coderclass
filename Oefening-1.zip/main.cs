using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine("Wat is jouw favoriete videogame?");
    string favGame = Console.ReadLine();
    Console.WriteLine ("Jouw favoriete spel is: " + favGame + "!");
  }
}