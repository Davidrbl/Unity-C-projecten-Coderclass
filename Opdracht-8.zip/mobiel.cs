class Mobiel
{
  public string type;
  public string model;
  public string OS;
  public string CEO;
  public double price;
  public double verzendkosten;

  public Mobiel(string nType, string nModel, string nOS, string nCEO, double nPrice, double nVerzendkosten)
  {
    type = nType;
    model = nModel;
    OS = nOS;
    CEO = nCEO;
    price = nPrice;
    verzendkosten = nVerzendkosten;
  }
}