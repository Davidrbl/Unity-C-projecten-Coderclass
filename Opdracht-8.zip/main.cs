using System;
using System.Linq;

class MainClass {
  public static void Main (string[] args) {
    double totalPrice = 0.00;
    double kortingPrijs = 1000.00;
    double kortingFactor = 0.8;
    double btwFactor = 1.21;
    Mobiel[] allMobiel = {
      new Mobiel("iPhone", "iPhone XS", "Apple IOS", "Steve Jobs", 829.00, 7.00), 
      new Mobiel("Samsung", "Galaxy S7", "Android", "Kim Hyun-suk, Koh Dong-Jin en Kim Ki Nam", 384.95, 5.00), 
      new Mobiel("Google Pixel", "Pixel 3", "Chrome OS", "Sundar Pichai", 319.00, 8.00)
    };
    foreach (Mobiel mob in allMobiel)
    {
      Console.WriteLine("Type: {0}, Model: {1}, OS: {2} Prijs: {3}, CEO: {4}", mob.type, mob.model, mob.OS, mob.cost(), mob.CEO);
    }
    Console.WriteLine("Welke telefoon wil jij?");
    string mobiel = Console.ReadLine();
    bool isCorrect = false;
    int mobielIndex = -1;
    for (int i = 0; i < allMobiel.Count(); i++)
    {
      if (mobiel == allMobiel[i].model)
      {
        mobielIndex = i;
        isCorrect = true;
      }
    }
    if (!isCorrect)
    {
      Console.WriteLine("Die staat niet in de lijst.");
    }
    Console.WriteLine("Hoeveel wil je daarvan?");
    int mobielaantal = 0;
    Int32.TryParse(Console.ReadLine(),out mobielaantal);
    totalPrice += allMobiel[mobielIndex].cost() * mobielaantal;
    if (totalPrice > kortingPrijs)
    {
      Console.WriteLine("Omdat u meer dan {0} euro heeft uitgegeven, krijgt u {1} procent korting!", kortingPrijs, kortingFactor * 100);
      totalPrice *= kortingFactor;

    }

    
    if (isCorrect)
    {
      Console.WriteLine("Je hebt {0} {1} gekozen", mobielaantal ,allMobiel[mobielIndex].model);

      Console.WriteLine("Dat kost dan exclusief BTW {0} euro, inclusief BTW {1} euro, en inclusief verzendkosten {2} euro.", totalPrice, totalPrice * btwFactor, totalPrice * btwFactor + allMobiel[mobielIndex].verzendkosten);
    }
    else
    {
      Console.WriteLine("Uw input was incorrect, probeer het nog een keer.");
    }
  }
}