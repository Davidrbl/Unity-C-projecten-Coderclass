using System;

class MainClass {
  public static void Main (string[] args) {
    string[] possibleOperators = {"+", "-", "x", "/"};

    bool correctCalculation = true;

    //Getal van user via input halen en storen=====//
    Console.WriteLine("Wat is jouw eerste getal?");

    int getal1;
    
    string sGetal1 = Console.ReadLine();

    bool sGetal1isInt = Int32.TryParse(sGetal1, out getal1);

    if (!sGetal1isInt)
    {
      Console.WriteLine("Dat is een ongeldige invoer!");
      correctCalculation = false;
    }

    //Operator van user via input halen en storen==//
    Console.WriteLine("Wat is jouw operator?");

    string operatorCal = Console.ReadLine();

    //Operator checking================================//
    bool isOperator = false;
    foreach (string Operator in possibleOperators)
    {
      if (operatorCal == Operator)
      {
        isOperator = true;
      }
    }
    if (!isOperator)
    {
      Console.WriteLine("Dat is een ongeldige operator!");
    }
    //Getal van user krijgen via input en storen====//
    Console.WriteLine("Wat is jouw tweede getal");

    int getal2;
    
    string sGetal2 = Console.ReadLine();

    bool sGetal2isInt = Int32.TryParse(sGetal2, out getal2);

    if (!sGetal2isInt)
    {
      Console.WriteLine("Dat is een ongeldige invoer!");
      correctCalculation = false;
    }

    //Calculaten======================================//
    if (!correctCalculation)
    {
      Console.WriteLine("Eén of meer van jouw inputs was in een incorrect type, probeer het opnieuw.");
    }
    else
    {
      switch(operatorCal)
      {
        case "+":
          Console.WriteLine(getal1 + getal2);
          break;
        case "-":
          Console.WriteLine(getal1 - getal2);
          break;
        case "x":
          Console.WriteLine(getal1 * getal2);
          break;
        case "/":
          Console.WriteLine(getal1 / getal2);
          break;
      }
    }
    }
  }
