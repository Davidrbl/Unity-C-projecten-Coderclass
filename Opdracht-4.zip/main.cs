using System;

class MainClass {
  public static void Main (string[] args) {

    string[] Woorden = {"Hond", "Toetsenbord", "Appel", "Oma", "Tas", "Water", "Hardloper", "Bord", "Printer", "Animatie"};

    int aantalKansen = 3;

    bool doorgaan = true;

    string woord = Woorden[new Random().Next(0, Woorden.Length)];

    Console.WriteLine(woord);

    for (int i = 0; (i < aantalKansen && doorgaan); i++)
    {
      Console.WriteLine("Wat denk je dat het woord is??");

      string geradenWoord = Console.ReadLine();
      
      if (geradenWoord == woord)
      {
        doorgaan = false;
        Console.WriteLine("Goed Geraden!");
      }
      else
      {
        Console.WriteLine("Helaas!");
      }
    }
    if (doorgaan)
    {
      Console.WriteLine("Het is je niet gelukt!");
    }
  }
}