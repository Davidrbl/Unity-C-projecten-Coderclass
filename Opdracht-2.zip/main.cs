using System;
using System.Collections.Generic;

class MainClass {
  public static void Main (string[] args) {
    double totalPrice = 0.00;
    double btwFactor = 1.21;
    int aantalBoodschappen = 3;
    Dictionary<string, double> allItems = new Dictionary<string, double>(){
      {"Appel", 1.5},
      {"Banaan", 2.0},
      {"Taart", 5.0},
      {"Komkommer",0.95},
      {"Boter", 2.5},
      {"Koffie", 3.0},
      {"Kauwgom", 1.0},
      {"Brood", 1.5},
      {"Snoep", 2.0},
      {"Kaas", 3.0},
      {"Ham", 2.5}
    };

    Console.WriteLine("Wat wilt u kopen:");
    foreach (KeyValuePair<string, double> ele in allItems)
    {
      Console.WriteLine("{0} voor {1} euro?", ele.Key, ele.Value);
    }

    for (int i = 0; i < aantalBoodschappen; i++)
    {
      Console.WriteLine("Wat wil je kopen?");
      string boodschap = Console.ReadLine();

      bool isCorrect = false;

      foreach (KeyValuePair<string, double> key in allItems)
      {
        if (key.Key == boodschap)
        {
          isCorrect = true;
        }
      }

      if (!isCorrect)
      {
        Console.WriteLine("Dat is een ongeldige invoer!");
        aantalBoodschappen++;
      }
      else
      {
        Console.WriteLine("Hoeveel wil je daarvan?");
        int aantalBoodschap = Int32.Parse(Console.ReadLine());
        totalPrice += allItems[boodschap] * aantalBoodschap;
      }
    }
    Console.WriteLine("Dat kost: "+ totalPrice + " euro!");
    Console.WriteLine("Inclusief btw is dat: " + totalPrice * btwFactor + "!");
  }
}